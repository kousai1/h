package com.S15.MusicStore;

import java.util.ArrayList;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.StoreObjects.CartItem;

import CustomListAdapters.CartItemsAdapter;
import android.app.Activity;
import android.content.Intent;
import android.database.CursorJoiner.Result;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

public class CartActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cart);
		invoiceid = 0;
		ListView lv = (ListView) findViewById(R.id.lvcart);
		CartItemsAdapter adp = new CartItemsAdapter(this, StoreObjects.GetCartItems(MainActivity.uid, this));
		lv.setAdapter(adp);
	}

	public static Integer invoiceid;
	private int updated;

	public void ViewClick(View v) {
		if (v.getId() == R.id.btnbuycart) {
			if (invoiceid == 0)
				Toast.makeText(this, "Nothing to buy", Toast.LENGTH_SHORT).show();
			else {
				Intent intent = new Intent(this, CartBuyActivity.class);
				startActivityForResult(intent, updated);
			}
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Toast.makeText(this, "Thank you! Please come again!", Toast.LENGTH_LONG).show();
			finish();
		}
	}
}
