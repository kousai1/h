package CustomListAdapters;

import java.util.ArrayList;

import com.S15.MusicStore.InvoiceSongsActivity;
import com.S15.MusicStore.MainActivity;
import com.S15.MusicStore.R;
import com.S15.MusicStore.Logic.StoreObjects.Artist;
import com.S15.MusicStore.Logic.StoreObjects.Invoice;
import com.S15.MusicStore.Logic.StoreObjects.Song;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class InvoicesAdapter extends ArrayAdapter<Invoice> {

	public InvoicesAdapter(Context c, ArrayList<Invoice> invoices) {
		super(c, R.layout.listview_invoices_row, invoices);
		listInvoices = invoices;
		context = c;
		// Toast.makeText(c, String.valueOf(listArtists.size()),
		// Toast.LENGTH_LONG).show();
		// TODO Auto-generated constructor stub
	}

	private Context context;
	private ArrayList<Invoice> listInvoices;

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflator = LayoutInflater.from(getContext());
		View row = inflator.inflate(R.layout.listview_invoices_row, parent, false);

		Invoice invoice = listInvoices.get(position);

		TextView viewprice = (TextView) row.findViewById(R.id.lvinvoiceprice);
		TextView viewdate = (TextView) row.findViewById(R.id.lvinvoicedate);
		TextView viewid = (TextView) row.findViewById(R.id.lvrowinvoiceid);
		
		viewprice.setText(String.valueOf(invoice.Total));
		viewdate.setText(invoice.Date);
		viewid.setText(String.valueOf(invoice.InvoiceId));
		viewid.setVisibility(View.GONE);

		row.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String invoiceid = String.valueOf(listInvoices.get(position).InvoiceId);
				Intent intent = new Intent(context, InvoiceSongsActivity.class);
				intent.putExtra("invoiceid", invoiceid);
				context.startActivity(intent);
			}
		});

		return row;
	}

}
