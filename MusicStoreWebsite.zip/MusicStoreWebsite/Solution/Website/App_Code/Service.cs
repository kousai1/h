﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Web.Configuration;
using System.Data;

/// <summary>
/// Summary description for Service
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService {

    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod]
    public bool Register(string un, string pw, string fn, string ln, string addr, string email)
    {
        if (!DAL.CustomerExists(un))
        {
            DAL.AddCustomer(un.ToLower(), pw.ToLower(), fn, ln, addr, email);
            return true;
        }
        else
        {
            return false;
        }
    }

    [WebMethod]
    public int Login(string un, string pw)
    {
        if (!DAL.LoginSuccess(un.ToLower(), pw.ToLower())) return 0;
        return DAL.GetCustomerId(un.ToLower(), pw.ToLower());
    }

    [WebMethod]
    public bool CorrectAdmin(string pw)
    {
        string apw = WebConfigurationManager.AppSettings["pw"];
        if (pw.ToLower() == apw.ToLower()) return true;
        else return false;
    }

    [WebMethod]
    public List<Artist> GetArtists(string search)
    {
        List<Artist> artists = new List<Artist>();
        DataSet ds = DAL.SearchArtists(search);
        for (int row = 0; row < ds.Tables[0].Rows.Count; row++)
        {
            Artist artist = new Artist();
            artist.Id = int.Parse(ds.Tables[0].Rows[row]["id"].ToString());
            artist.FirstName = ds.Tables[0].Rows[row]["fname"].ToString();
            artist.LastName = ds.Tables[0].Rows[row]["lname"].ToString();
            artist.Gender = ds.Tables[0].Rows[row]["gender"].ToString();
            artist.Country = ds.Tables[0].Rows[row]["country"].ToString();
            artists.Add(artist);
        }
        return artists;
    }

    [WebMethod]
    public List<Song> GetSongs(string search)
    {
        List<Song> songs = new List<Song>();
        DataSet ds = DAL.SearchSongs(search);
        for (int row = 0; row < ds.Tables[0].Rows.Count; row++)
        {
            Song song = new Song();
            song.Id = int.Parse(ds.Tables[0].Rows[row]["id"].ToString());
            song.Title = ds.Tables[0].Rows[row]["title"].ToString();
            song.ArtistFullName = ds.Tables[0].Rows[row]["artistname"].ToString();
            song.Type = ds.Tables[0].Rows[row]["type"].ToString();
            song.Price = float.Parse(ds.Tables[0].Rows[row]["price"].ToString());
            song.ArtistId = int.Parse(ds.Tables[0].Rows[row]["artid"].ToString());
            songs.Add(song);
        }
        return songs;
    }

    [WebMethod]
    public bool DeleteSong(string id)
    {
        DAL.DeleteSong(int.Parse(id));
        return true;
    }

    [WebMethod]
    public bool DeleteArtist(string id)
    {
        DAL.DeleteArtist(int.Parse(id));
        return true;
    }

    [WebMethod]
    public bool AddArtist(string fname, string lname, string gender, string country)
    {
        DAL.AddArtist(fname, lname, gender, country);
        return true;
    }

    [WebMethod]
    public bool AddSong(string title, string type, string price, string artistid)
    {
        DAL.AddSong(title, type, float.Parse(price), int.Parse(artistid));
        return true;
    }

    [WebMethod]
    public bool DeleteCartItem(string orderid)
    {
        DAL.DeleteCartSong(int.Parse(orderid));
        return true;
    }


    [WebMethod]
    public bool AddToCart(string custid, string songid)
    {
        DAL.BuySong(int.Parse(custid), int.Parse(songid));
        return true;
    }

    [WebMethod]
    public bool CartBuy(string custid, string cc)
    {
        DAL.BuyCart(int.Parse(custid), cc);
        return true;
    }

    [WebMethod]
    public List<Invoice> GetInvoices(string custid)
    {
        List<Invoice> invoices = new List<Invoice>();
        DataSet db = DAL.Invoices(int.Parse(custid));
        for (int i = 0; i < db.Tables[0].Rows.Count; i++)
        {
            Invoice invoice = new Invoice();
            invoice.InvoiceId = int.Parse(db.Tables[0].Rows[i]["id"].ToString());
            invoice.Total = float.Parse(db.Tables[0].Rows[i]["total"].ToString());
            invoice.Date = DateTime.Parse(db.Tables[0].Rows[i]["date"].ToString()).ToString("dd/MM/yyyy");
            invoices.Add(invoice);
        }

        return invoices;
    }

    [WebMethod]
    public List<CartItem> GetCartItems(string custid)
    {
        List<CartItem> cart = new List<CartItem>();
        DataSet db = DAL.CartSongs(int.Parse(custid));
        for (int i = 0; i < db.Tables[0].Rows.Count; i++)
        {
            CartItem item = new CartItem();
            item.OrderId = int.Parse(db.Tables[0].Rows[i]["orderid"].ToString());
            item.InvoiceId = int.Parse(db.Tables[0].Rows[i]["invoiceid"].ToString());
            item.SongTitle = db.Tables[0].Rows[i]["title"].ToString();
            item.ArtistFullName = db.Tables[0].Rows[i]["artistfullname"].ToString();
            item.Price = float.Parse(db.Tables[0].Rows[i]["price"].ToString());
            cart.Add(item);
        }

        return cart;
    }

    [WebMethod]
    public List<Song> GetInvoiceSongs(string invoiceid)
    {
        List<Song> songs = new List<Song>();
        DataSet db = DAL.InvoiceSongs(int.Parse(invoiceid));

        for (int i = 0; i < db.Tables[0].Rows.Count; i++)
        {
            Song song = new Song();
            song.Title = db.Tables[0].Rows[i]["title"].ToString();
            song.ArtistFullName = db.Tables[0].Rows[i]["artistfullname"].ToString();
            song.Price = float.Parse(db.Tables[0].Rows[i]["price"].ToString());

            songs.Add(song);
        }

        return songs;
    }

}

public class Artist
{
    public int Id;
    public string FirstName;
    public string LastName;
    public string Gender;
    public string Country;
}

public class Song
{
    public int Id;
    public string Title;
    public float Price;
    public string ArtistFullName;
    public int ArtistId;
    public string Type;
}

public class Invoice
{
    public int InvoiceId;
    public float Total;
    public string Date;
}

public class CartItem
{
    public int OrderId;
    public int InvoiceId;
    public string SongTitle;
    public string ArtistFullName;
    public float Price;
}