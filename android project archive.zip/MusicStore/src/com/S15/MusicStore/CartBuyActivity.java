package com.S15.MusicStore;

import java.util.ArrayList;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.StoreObjects.CartItem;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CartBuyActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cart_buy);
		ArrayList<CartItem> items = StoreObjects.GetCartItems(MainActivity.uid, this);
		TextView countview = (TextView) findViewById(R.id.txttotsongs);
		TextView priceview = (TextView) findViewById(R.id.txttotprice);
		Integer count = 0;
		Float price = Float.parseFloat("0");
		for (CartItem cartItem : items) {
			count++;
			price += cartItem.Price;
		}
		countview.setText(String.valueOf(count));
		priceview.setText(String.valueOf(price));
	}

	public void ViewClick(View v) {
		TextView cc = (TextView) findViewById(R.id.txtcc);
		if (cc.getText().toString().matches("")) {
			Toast.makeText(this, "Credit Card is required", Toast.LENGTH_LONG).show();
			return;
		}
		Boolean res = StoreObjects.CartBuy(MainActivity.uid, cc.getText().toString(), this);
		if (res) {
			this.setResult(RESULT_OK);
			finish();
		} else {
			Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
		}
	}

}
