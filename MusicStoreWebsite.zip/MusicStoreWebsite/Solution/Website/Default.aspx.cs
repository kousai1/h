using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string pw = WebConfigurationManager.AppSettings["pw"];
        if (txtuname.Text.ToLower() == "admin" & txtpw.Text.ToLower() == pw)
        {
            Session["admin"] = true;
            Session["id"] = null;
            Server.Transfer("~/Menu.aspx");
            //Response.Redirect("~/Menu.aspx",false);
        }
        else
        {
            if (DAL.LoginSuccess(txtuname.Text.ToLower(), txtpw.Text.ToLower()))
            {
                Session["admin"] = false;
                Session["id"] = DAL.GetCustomerId(txtuname.Text.ToLower(), txtpw.Text.ToLower());
                Server.Transfer("~/Menu.aspx");
                //Response.Redirect("~/Menu.aspx",false);
            }
        }               
    }
}
