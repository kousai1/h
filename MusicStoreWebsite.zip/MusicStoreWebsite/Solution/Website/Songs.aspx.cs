using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Songs : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["admin"] == null) Server.Transfer("~/default.aspx");
            if ((bool)Session["admin"] == true)
            {
                olsongs.Commands.Remove("buy");
            }
            else
            {
                olsongs.Commands.Remove("delete");
                lnkAddSong.Visible = false;
            }

            olsongs.DataSource = DAL.Songs();
            selartist.DataSource = DAL.Artists();
            selartist.DataTextField = "fullname";
            selartist.DataValueField = "id";
            Page.DataBind();
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            DAL.AddSong(txttitle.Text, seltype.Items[seltype.SelectedIndex].Text, float.Parse(txtprice.Text), int.Parse(selartist.Items[selartist.SelectedIndex].Value));
            Server.Transfer("~/Songs.aspx");
        }
    }
    protected void olsongs_ItemCommand(object sender, ObjectListCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string id = e.ListItem["id"];
            DAL.DeleteSong(int.Parse(id));
            Server.Transfer("~/Songs.aspx");
        }
        else if (e.CommandName == "artist")
        {
            string artid = e.ListItem["artid"];
            DataSet ds = DAL.ArtistById(int.Parse(artid));
            txtfullname.Text = "Full Name: " + ds.Tables[0].Rows[0]["fullname"];
            txtgender.Text = "Gender: " + ds.Tables[0].Rows[0]["gender"];
            txtcountry.Text = "Country: " + ds.Tables[0].Rows[0]["country"];
            ActiveForm = Form3;
        }
        else if (e.CommandName == "buy")
        {
            int songid = int.Parse(e.ListItem["id"]);
            int cusid = int.Parse(Session["id"].ToString());
            DAL.BuySong(cusid,songid);
             Server.Transfer("~/Songs.aspx");
        }
    }
}
