using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class SearchSong : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["admin"] == null) Server.Transfer("~/default.aspx");
            if ((bool)Session["admin"] == true)
            {
                olsongs.Commands.Remove("buy");
            }
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ActiveForm = Form2;
        olsongs.DataSource = DAL.SearchSongs(txtsearch.Text);
        Page.DataBind();
    }
    protected void olsongs_ItemCommand(object sender, ObjectListCommandEventArgs e)
    {
        if (e.CommandName == "buy")
        {
            int songid = int.Parse(e.ListItem["id"]);
            int cusid = int.Parse(Session["id"].ToString());
            DAL.BuySong(cusid,songid);
            ActiveForm = Form1;
        }
    }
}
