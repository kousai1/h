using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Register : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            if (!DAL.CustomerExists(txtuname.Text))
            {
                DAL.AddCustomer(txtuname.Text.ToLower(), txtpw.Text.ToLower(), txtfname.Text, txtlname.Text, txtaddr.Text, txtemail.Text);
                lblstatus.Visible = true;
                lblstatus.Text = "User created successfully";
            }
            else
            {
                lblstatus.Visible = true;
                lblstatus.Text = "Sorry! User Already Exist.";
            }
        }
    }
}
