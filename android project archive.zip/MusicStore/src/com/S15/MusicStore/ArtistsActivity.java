package com.S15.MusicStore;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.StoreObjects.Artist;

import CustomListAdapters.ArtistsAdapter;
import CustomListAdapters.SongsAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ArtistsActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		artistsearch = getIntent().getStringExtra("artistsearch");
		PrepareList();
	}

	String artistsearch;
	private int updated;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.artists_menu, menu);
		if (!MainActivity.isAdmin)
			return false;
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if (item.getItemId() == R.id.artistaddnew) {
			Intent intent = new Intent(this, AddArtistActivity.class);
			startActivityForResult(intent, updated);
		}
		return true;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		PrepareList();
	}

	public void ViewClick(View v) {
		switch (v.getId()) {
		case R.id.btncancelartist:
			break;
		case R.id.btnsongssang:
			TextView artistid = (TextView) findViewById(R.id.hiddenartistid);
			Intent intent = new Intent(this, SongsActivity.class);
			intent.putExtra("artistid", Integer.parseInt(artistid.getText().toString()));
			startActivity(intent);

			break;
		}
		PrepareList();
	}

	private void PrepareList() {
		setContentView(R.layout.activity_artists);
		ListView lv = (ListView) findViewById(R.id.lvartists);

		ArtistsAdapter adp = new ArtistsAdapter(this, StoreObjects.GetArtists(artistsearch, this));
		lv.setAdapter(adp);
	}

}
