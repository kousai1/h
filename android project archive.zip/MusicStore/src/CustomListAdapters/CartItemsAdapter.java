package CustomListAdapters;

import java.util.ArrayList;

import com.S15.MusicStore.CartActivity;
import com.S15.MusicStore.MainActivity;
import com.S15.MusicStore.R;
import com.S15.MusicStore.Logic.StoreObjects.Artist;
import com.S15.MusicStore.Logic.StoreObjects.CartItem;
import com.S15.MusicStore.Logic.StoreObjects.Song;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CartItemsAdapter extends ArrayAdapter<CartItem> {

	public CartItemsAdapter(Context c, ArrayList<CartItem> cartitems) {
		super(c, R.layout.listview_cartitem_row, cartitems);
		listCartItems = cartitems;
		context = c;
		
		if (listCartItems.size() > 0)
			CartActivity.invoiceid = listCartItems.get(0).InvoiceId;
		else
			CartActivity.invoiceid = 0;
		// Toast.makeText(c, String.valueOf(listArtists.size()),
		// Toast.LENGTH_LONG).show();
		// TODO Auto-generated constructor stub
	}

	private Context context;
	private ArrayList<CartItem> listCartItems;

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflator = LayoutInflater.from(getContext());
		View row = inflator.inflate(R.layout.listview_cartitem_row, parent, false);

		CartItem cartitem = listCartItems.get(position);

		TextView viewsong = (TextView) row.findViewById(R.id.lvsong);
		TextView viewartist = (TextView) row.findViewById(R.id.lvsongfullartist);
		TextView viewprice = (TextView) row.findViewById(R.id.lvsongprice);
		/////////////// the delete icon
		TextView delete = (TextView) row.findViewById(R.id.lvdelcartitem);

		delete.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setMessage("Are you sure to delete?").setNegativeButton("No", null).setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// Use mListRowPosition for clicked list row...
						CartItem item = listCartItems.get(position);
						Boolean res = item.Delete(context);
						if (res) {
							listCartItems.remove(item);
							notifyDataSetChanged();
							if (listCartItems.size() > 0)
								CartActivity.invoiceid = listCartItems.get(0).InvoiceId;
							else
								CartActivity.invoiceid = 0;
						} else {
							Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show();
						}
					}
				});
				builder.show();
			}
		});

		viewsong.setText(cartitem.SongTitle.toString());
		viewartist.setText(cartitem.ArtistFullName.toString());
		viewprice.setText(String.valueOf(cartitem.Price));

		return row;
	}

}
