/** Automatically generated file. DO NOT MODIFY */
package com.S15.MusicStore;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}