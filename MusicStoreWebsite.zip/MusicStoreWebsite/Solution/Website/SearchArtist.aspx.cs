using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class SearchSong : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["admin"] == null) Server.Transfer("~/default.aspx");
            if ((bool)Session["admin"] == true)
            {
                olsongs.Commands.Remove("buy");
            }
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ActiveForm = Form2;
        olArtists.DataSource = DAL.SearchArtists(txtsearch.Text);
        Page.DataBind();
    }
    protected void olArtists_ItemCommand(object sender, ObjectListCommandEventArgs e)
    {
        if (e.CommandName == "songs")
        {
            string artid = e.ListItem["id"];
            olsongs.DataSource = DAL.SongsByArtist(int.Parse(artid));
            olsongs.DataBind();
            ActiveForm = Form3;
        }
    }
    protected void olsongs_ItemCommand(object sender, ObjectListCommandEventArgs e)
    {
         if (e.CommandName == "buy")
        {
            int songid = int.Parse(e.ListItem["id"]);
            int cusid = 10;
            DAL.BuySong(cusid,songid);
            //Response.Redirect("");
        }
    }
}
