package CustomListAdapters;

import java.util.ArrayList;

import com.S15.MusicStore.MainActivity;
import com.S15.MusicStore.R;
import com.S15.MusicStore.Logic.StoreObjects.Artist;
import com.S15.MusicStore.Logic.StoreObjects.Invoice;
import com.S15.MusicStore.Logic.StoreObjects.Song;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class InvoiceSongsAdapter extends ArrayAdapter<Song> {

	public InvoiceSongsAdapter(Context c, ArrayList<Song> songs) {
		super(c, R.layout.listview_cartitem_row, songs);
		listSongs = songs;
		context = c;
		// Toast.makeText(c, String.valueOf(listArtists.size()),
		// Toast.LENGTH_LONG).show();
		// TODO Auto-generated constructor stub
	}

	private Context context;
	private ArrayList<Song> listSongs;

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflator = LayoutInflater.from(getContext());
		View row = inflator.inflate(R.layout.listview_cartitem_row, parent, false);

		Song song = listSongs.get(position);

		TextView viewtitle = (TextView) row.findViewById(R.id.lvsong);
		TextView viewartist = (TextView) row.findViewById(R.id.lvsongfullartist);
		TextView viewprice = (TextView) row.findViewById(R.id.lvsongprice);
		
		
		viewtitle.setText(song.Title);
		viewartist.setText(song.ArtistFullName);
		viewprice.setText(String.valueOf(song.Price));
		
		row.findViewById(R.id.lvdelcartitem).setVisibility(View.GONE);
		
		return row;
	}

}
