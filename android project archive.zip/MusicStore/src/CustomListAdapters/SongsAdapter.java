package CustomListAdapters;

import java.util.ArrayList;

import com.S15.MusicStore.MainActivity;
import com.S15.MusicStore.R;
import com.S15.MusicStore.Logic.StoreObjects.Artist;
import com.S15.MusicStore.Logic.StoreObjects.Song;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SongsAdapter extends ArrayAdapter<Song> {

	public SongsAdapter(Context c, ArrayList<Song> songs) {
		super(c, R.layout.listview_song_row, songs);
		listSongs = songs;
		context = c;
		// Toast.makeText(c, String.valueOf(listArtists.size()),
		// Toast.LENGTH_LONG).show();
		// TODO Auto-generated constructor stub
	}

	private Context context;
	private ArrayList<Song> listSongs;

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflator = LayoutInflater.from(getContext());
		View row = inflator.inflate(R.layout.listview_song_row, parent, false);

		Song song = listSongs.get(position);

		TextView viewsong = (TextView) row.findViewById(R.id.lvsongtitle);
		TextView viewartist = (TextView) row.findViewById(R.id.lvsongartist);
		///////////////// the delete icon
		TextView delete = (TextView) row.findViewById(R.id.lvdelsong);
		if (!MainActivity.isAdmin)
			delete.setVisibility(View.GONE);
		else {
			delete.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					AlertDialog.Builder builder = new AlertDialog.Builder(context);
					builder.setMessage("Are you sure to delete?").setNegativeButton("No", null).setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							// Use mListRowPosition for clicked list row...
							Song item = listSongs.get(position);
							Boolean res = item.Delete(context);
							if (res) {
								listSongs.remove(item);
								notifyDataSetChanged();
							} else {
								Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show();
							}
						}
					});
					builder.show();
				}
			});

		}

		viewsong.setText(song.Title);
		viewartist.setText(song.ArtistFullName);

		row.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Toast.makeText(context, String.valueOf(position),
				// Toast.LENGTH_LONG).show();
				// TODO Auto-generated method stub
				Activity activity = (Activity) context;
				activity.setContentView(R.layout.song_detail);
				Song theSong = listSongs.get(position);
				TextView id = (TextView) activity.findViewById(R.id.songdetailid);
				TextView title = (TextView) activity.findViewById(R.id.songdetailtitle);
				TextView type = (TextView) activity.findViewById(R.id.songdetailtype);
				TextView artist = (TextView) activity.findViewById(R.id.songdetailartist);
				TextView price = (TextView) activity.findViewById(R.id.songdetailprice);
				id.setText(String.valueOf(theSong.Id));
				id.setVisibility(View.GONE);
				title.setText(theSong.Title);
				type.setText(theSong.Type);
				artist.setText(theSong.ArtistFullName);
				price.setText(String.valueOf(theSong.Price));
				Button btn = (Button)activity.findViewById(R.id.btnbuysong);
				if(MainActivity.isAdmin) btn.setVisibility(View.GONE);
			}
		});

		return row;
	}

}
