using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Menu : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["admin"] == null) Server.Transfer("~/default.aspx");
            else if ((bool)Session["admin"] == true)
            {
                Link5.Visible = false;
                Link6.Visible = false;
            }
        }
    }
    protected void Command1_Click(object sender, EventArgs e)
    {
        Session["admin"]=null;
        Session["id"]=null;
        //Session.Abandon();
        Server.Transfer("~/default.aspx");
        //Response.Redirect(ResolveUrl("~/default.aspx"));
        //Response.Redirect("Default.aspx");
    }
}
