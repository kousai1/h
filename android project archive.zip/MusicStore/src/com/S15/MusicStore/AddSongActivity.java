package com.S15.MusicStore;

import java.util.ArrayList;

import com.S15.MusicStore.Logic.StoreObjects;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class AddSongActivity extends Activity {

	EditText title;
	EditText price;
	Spinner artist;
	Spinner type;
	ArrayList<StoreObjects.Artist> artists;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_song);
		artists = StoreObjects.GetArtists("", this);
		ArrayList<String> artistslist = new ArrayList<String>();
		for (int i = 0; i < artists.size(); i++) {
			artistslist.add(artists.get(i).FirstName + " " + artists.get(i).LastName);
		}

		title = (EditText) findViewById(R.id.txtsongtitle);
		price = (EditText) findViewById(R.id.txtsongprice);
		artist = (Spinner) findViewById(R.id.spinnersongartists);
		type = (Spinner) findViewById(R.id.spinnersongstypes);
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, artistslist);
		artist.setAdapter(adapter);
	}

	public void ViewClick(View v) {
		switch (v.getId()) {
		case R.id.btnaddsong:
			if (title.getText().toString().matches("")) {
				Toast.makeText(this, "Title is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (price.getText().toString().matches("")) {
				Toast.makeText(this, "Price is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (Float.parseFloat(price.getText().toString())<1) {
				Toast.makeText(this, "Price should be 1 or more", Toast.LENGTH_SHORT).show();
				return;
			}
			if (artist.getSelectedItemPosition() == -1) {
				Toast.makeText(this, "Artist is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (type.getSelectedItemPosition() == -1) {
				Toast.makeText(this, "Type is required", Toast.LENGTH_SHORT).show();
				return;
			}
			StoreObjects.Song song = new StoreObjects().Song();
			song.Title = title.getText().toString();
			song.Price = Float.parseFloat(price.getText().toString());
			song.Type = type.getItemAtPosition(type.getSelectedItemPosition()).toString();
			song.ArtistId = artists.get(artist.getSelectedItemPosition()).Id;
			
			//Toast.makeText(this, song.Title + song.Price + song.Type + song.ArtistId, Toast.LENGTH_LONG).show();
			Boolean result = StoreObjects.AddSong(song, this);
			if (result) {
				Toast.makeText(this, "New Song added!", Toast.LENGTH_SHORT).show();
				title.setText("");
				price.setText("");
				//gender.setSelected(false);
				//country.setSelected(false);
			} else {
				Toast.makeText(this, "failed! try later", Toast.LENGTH_SHORT).show();
			}

			break;
		case R.id.btncanceladdsong:
			this.finish();
			break;
		}
	}

}
