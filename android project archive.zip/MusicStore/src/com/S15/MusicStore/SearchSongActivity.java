package com.S15.MusicStore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SearchSongActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search_song);
	}

	public void ViewClick(View view) {
		EditText search = (EditText) findViewById(R.id.txtsearchsong);
		Intent intent = new Intent(this, SongsActivity.class);
		
		intent.putExtra("songsearch", search.getText().toString());
		startActivity(intent);
	}

}
