using System;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Collections;
using System.Data;

public class DAL
{
    public static void AddArtist(string fname, string lname, string gender, string country)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "insert into artist(fname,lname,gender,country) values(@fname,@lname,@gender,@country)";
        cm.Parameters.Add(new SqlParameter("fname", fname));
        cm.Parameters.Add(new SqlParameter("lname", lname));
        cm.Parameters.Add(new SqlParameter("gender", gender));
        cm.Parameters.Add(new SqlParameter("country", country));
        cm.ExecuteNonQuery();
        cm.Connection.Close();
    }
    public static DataSet Artists()
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet artists = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select id, fname, lname, gender, country,
                fname + ' ' + lname as fullname from artist";
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(artists);
        cm.Connection.Close();
        return artists;
    }
    public static void DeleteArtist(int id)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "delete from artist where id = @id";
        cm.Parameters.Add(new SqlParameter("id", id));
        cm.ExecuteNonQuery();
        cm.Connection.Close();
    }
    public static DataSet SearchArtists(string flname)
    {
        string cr = "fname like '%" + flname + "%' OR lname like '%" + flname + "%'";
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet artists = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select id, fname, lname, gender, country,
                fname + ' ' + lname as fullname from artist where " + cr;
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(artists);
        cm.Connection.Close();
        return artists;
    }
    public static DataSet ArtistById(int id)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet artist = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select id, fname, lname, gender, country,
                fname + ' ' + lname as fullname from artist where id = @id";
        cm.Parameters.Add(new SqlParameter("id", id));
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(artist);
        cm.Connection.Close();
        return artist;
    }



    public static void DeleteSong(int id)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "delete from song where id = @id";
        cm.Parameters.Add(new SqlParameter("id", id));
        cm.ExecuteNonQuery();
        cm.Connection.Close();
    }
    public static void AddSong(string title, string type, float price, int artistid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "insert into song(title,type,price,artistid) values(@title,@type,@price,@artistid)";
        cm.Parameters.Add(new SqlParameter("title", title));
        cm.Parameters.Add(new SqlParameter("type", type));
        cm.Parameters.Add(new SqlParameter("price", price));
        cm.Parameters.Add(new SqlParameter("artistid", artistid));
        cm.ExecuteNonQuery();
        cm.Connection.Close();
    }
    public static DataSet Songs()
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet songs = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select song.id, title, [type], price
                , artist.fname + ' ' + artist.lname as artistname, artist.id as artid
                from song, artist where artist.id = song.artistid";
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(songs);
        cm.Connection.Close();
        return songs;
    }
    public static DataSet SearchSongs(string title)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet songs = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select song.id, title, [type], price
                , artist.fname + ' ' + artist.lname as artistname, artist.id as artid
                from song, artist where artist.id = song.artistid and title like '%" + title + "%'";
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(songs);
        cm.Connection.Close();
        return songs;
    }
    public static DataSet SongsByArtist(int id)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet songs = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select song.id, title, [type], price
                , artist.fname + ' ' + artist.lname as artistname, artist.id as artid
                from song, artist where artist.id = song.artistid AND artist.id = @artid";
        cm.Parameters.Add(new SqlParameter("artid", id));
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(songs);
        cm.Connection.Close();
        return songs;
    }
    public static void BuySong(int cusid, int songid)
    {
        int invid = GetInvoiceNumber(cusid);
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "insert into [order](songid, invoiceid) values(@songid, @invid)";
        cm.Parameters.Add(new SqlParameter("songid", songid));
        cm.Parameters.Add(new SqlParameter("invid", invid));
        cm.ExecuteNonQuery();
        cn.Close();
    }
    public static int GetInvoiceNumber(int custid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select count(*) from invoice
                where date is null AND customerid = @custid";
        cm.Parameters.Add(new SqlParameter("custid", custid));
        int count = (int)cm.ExecuteScalar();
        if (count > 0)
        {
            cm.CommandText = @"select id from invoice
                where date is null AND customerid = @custid";

            int id = (int)cm.ExecuteScalar();
            cn.Close();
            return id;
        }
        else
        {
            SqlConnection cn2 = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cm2 = new SqlCommand();
            cm2.Connection = cn2;
            cm2.Connection.Open();
            cm2.CommandText = @"insert into invoice(customerid, total)
                values (@cusid,0); SELECT CAST(@@identity AS int)";
            cm2.Parameters.Add(new SqlParameter("cusid", custid));
            int id = (int)cm2.ExecuteScalar();
            cn2.Close();
            return id;
        }
    }
    public static DataSet CartSongs(int custid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet cartsongs = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select [order].id as orderid, [order].invoiceid, song.title,
                artist.fname + ' ' + artist.lname as artistfullname, song.price
                from [order], song, artist,
		                (
		                select top 1 invoice.id as invid
		                from invoice
		                where invoice.customerid = @cusid AND date is null
		                ) as dt
                where [order].invoiceid = dt.invid
                AND [order].songid = song.id
                AND song.artistid = artist.id";
        cm.Parameters.Add(new SqlParameter("cusid", custid));
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(cartsongs);
        cm.Connection.Close();
        return cartsongs;
    }
    public static void DeleteCartSong(int orid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "delete from [order] where id = @orid";
        cm.Parameters.Add(new SqlParameter("orid", orid));
        cm.ExecuteNonQuery();
        cn.Close();
    }
    public static float CartTotalPrice(int custid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select ISNULL(SUM(song.price),0) as total
                from [order], song
                where [order].songid = song.id
                AND [order].invoiceid = (
		                select top 1 invoice.id as invid
		                from invoice
		                where invoice.customerid = @custid AND date is null
		                )";
        cm.Parameters.Add(new SqlParameter("custid", custid));
        float total = float.Parse(cm.ExecuteScalar().ToString());
        cn.Close();
        return total;
    }
    public static void BuyCart(int custid, string cridcard)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        float prc = CartTotalPrice(custid);
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"update invoice
                set total = @prc, ccard = @cridcard, date = @dt
                where invoice.id = (
		                select top 1 invoice.id as invid
		                from invoice
		                where invoice.customerid = @custid AND date is null
		                )";
        cm.Parameters.Add(new SqlParameter("custid", custid));
        cm.Parameters.Add(new SqlParameter("prc", prc));
        cm.Parameters.Add(new SqlParameter("dt", DateTime.Now));
        cm.Parameters.Add(new SqlParameter("cridcard", cridcard));
        cm.ExecuteNonQuery();
        cn.Close();
    }
    public static DataSet Invoices(int custid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet invoices = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select * from invoice where customerid = @cusid AND date IS NOT NULL";
        cm.Parameters.Add(new SqlParameter("cusid", custid));
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(invoices);
        cm.Connection.Close();
        return invoices;
    }
    public static DataSet InvoiceSongs(int invid)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        DataSet songs = new DataSet();
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = @"select title, [type], price, artist.fname + ' ' + artist.lname as artistfullname
                    from song, artist
                    where song.id in
	                    (select songid
	                    from [order]
	                    where [order].invoiceid = @invid)
                    AND song.artistid = artist.id";
        cm.Parameters.Add(new SqlParameter("invid", invid));
        SqlDataAdapter da = new SqlDataAdapter(cm);
        da.Fill(songs);
        cm.Connection.Close();
        return songs;
    }


    public static void AddCustomer(string uname, string pw, string fname, string lname, string addr, string email)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "insert into customer(uname,pw,fname,lname,addr,email) values(@uname,@pw,@fname,@lname,@addr,@email)";
        cm.Parameters.Add(new SqlParameter("uname", uname));
        cm.Parameters.Add(new SqlParameter("pw", pw));
        cm.Parameters.Add(new SqlParameter("fname", fname));
        cm.Parameters.Add(new SqlParameter("lname", lname));
        cm.Parameters.Add(new SqlParameter("addr", addr));
        cm.Parameters.Add(new SqlParameter("email", email));
        cm.ExecuteNonQuery();
        cm.Connection.Close();
    }
    public static bool CustomerExists(string uname)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "select count(*) from customer where uname = @uname";
        cm.Parameters.Add(new SqlParameter("uname", uname));
        int count = (int)cm.ExecuteScalar();
        cm.Connection.Close();
        if (count <= 0)
            return false;
        else return true;
    }
    public static bool LoginSuccess(string uname, string pw)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "select count(*) from customer where uname = @uname AND pw = @pw";
        cm.Parameters.Add(new SqlParameter("uname", uname));
        cm.Parameters.Add(new SqlParameter("pw", pw));
        int count = (int)cm.ExecuteScalar();
        cm.Connection.Close();
        if (count <= 0)
            return false;
        else return true;
    }
    public static int GetCustomerId(string uname, string pw)
    {
        SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["db"].ToString());
        SqlCommand cm = new SqlCommand();
        cm.Connection = cn;
        cm.Connection.Open();
        cm.CommandText = "select ISNULL(id,0) from customer where pw = @pw AND uname = @uname";
        cm.Parameters.Add(new SqlParameter("uname", uname));
        cm.Parameters.Add(new SqlParameter("pw", pw));
        int id = (int)cm.ExecuteScalar();
        cm.Connection.Close();
        return id;
    }
}