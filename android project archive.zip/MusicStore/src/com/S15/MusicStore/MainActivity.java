package com.S15.MusicStore;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.Support;

import java.util.ArrayList;
import java.util.regex.*;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
	public static Boolean isAdmin;
	public static Integer uid;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		/*
		 * testing only ArrayList<StoreObjects.Artist> artists
		 * =StoreObjects.GetArtists("", this);
		 * 
		 * Toast.makeText(this, artists.get(0).FirstName,
		 * Toast.LENGTH_LONG).show();
		 * 
		 */
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void ViewClick(View view) {
		int id = view.getId();
		switch (id) {
		case R.id.btnSaveURL:
			EditText ed = (EditText) findViewById(R.id.txtServiceURL);
			Support.SaveURL(ed.getText().toString(), this);
			setContentView(R.layout.activity_main);
			getActionBar().setTitle(R.string.app_name);
			Toast.makeText(this, "URL Saved!", Toast.LENGTH_SHORT).show();
			break;

		case R.id.btnCancelURL:
			setContentView(R.layout.activity_main);
			getActionBar().setTitle(R.string.app_name);
			break;

		case R.id.btnCancelRegister:
			setContentView(R.layout.activity_main);
			getActionBar().setTitle(R.string.app_name);
			break;

		case R.id.btnLogin:
			////////////////////// Login process!!!!!!
			Toast.makeText(this, "Trying to login ...", Toast.LENGTH_SHORT).show();

			EditText lun = (EditText) findViewById(R.id.txtloginUserName);
			EditText lpw = (EditText) findViewById(R.id.txtloginPassword);

			if (lun.getText().toString().toLowerCase().matches("admin")) {
				isAdmin = Support.ValidateAdmin(lpw.getText().toString(), this);
				if (isAdmin) {
					uid = 0;
					/////// switch to Musicstore
					Intent intent = new Intent(this, MenuActivity.class);
					startActivity(intent);
				} else {
					Toast.makeText(this, "Admin login failed", Toast.LENGTH_SHORT).show();
				}
				break;
			}
			uid = Support.Login(lun.getText().toString(), lpw.getText().toString(), this);
			if (uid == 0) {
				Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show();
			} else {
				isAdmin = false;
				/////// switch to Musicstore
				Intent intent = new Intent(this, MenuActivity.class);
				startActivity(intent);
			}
			break;

		case R.id.btnRegister:
			////////////////////// Registration process!!!!!!
			EditText run = (EditText) findViewById(R.id.run);
			EditText rpw = (EditText) findViewById(R.id.rpw);
			EditText rrpw = (EditText) findViewById(R.id.rrpw);
			EditText rfn = (EditText) findViewById(R.id.rfn);
			EditText rln = (EditText) findViewById(R.id.rln);
			EditText raddr = (EditText) findViewById(R.id.raddr);
			EditText rmail = (EditText) findViewById(R.id.rmail);

			String un = run.getText().toString();
			String pw = rpw.getText().toString();
			String repw = rrpw.getText().toString();
			String fn = rfn.getText().toString();
			String ln = rln.getText().toString();
			String addr = raddr.getText().toString();
			String mail = rmail.getText().toString();

			if (un.matches("")) {
				Toast.makeText(this, "Username is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (pw.matches("")) {
				Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (repw.matches("")) {
				Toast.makeText(this, "Retype Password is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (!repw.matches(pw)) {
				Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
				return;
			}

			if (fn.matches("")) {
				Toast.makeText(this, "First Name is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (ln.matches("")) {
				Toast.makeText(this, "Last Name is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (addr.matches("")) {
				Toast.makeText(this, "Address is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (mail.matches("")) {
				Toast.makeText(this, "Email is required", Toast.LENGTH_SHORT).show();
				return;
			}

			Pattern pat = Patterns.EMAIL_ADDRESS;
			Matcher mat = pat.matcher(mail);
			if (!mat.matches()) {
				Toast.makeText(this, "Email is not correct", Toast.LENGTH_SHORT).show();
				return;
			}
			Toast.makeText(this, "Registering ...", Toast.LENGTH_SHORT).show();
			Boolean result = Support.Register(un, pw, fn, ln, addr, mail, this);

			if (result == true) {
				setContentView(R.layout.activity_main);
				Toast.makeText(this, "User " + un + " has been created!", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Username already exist", Toast.LENGTH_SHORT).show();
			}
			break;
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.menuSetup) {
			setContentView(R.layout.activity_setup);
			getActionBar().setTitle("Service Setup");
			EditText ed = (EditText) findViewById(R.id.txtServiceURL);
			ed.setText(Support.GetURL(this));
		} else if (id == R.id.menuRegister) {
			setContentView(R.layout.activity_register);
			getActionBar().setTitle("Register");
		}

		return true;
	}
}
