package CustomListAdapters;

import java.util.ArrayList;

import com.S15.MusicStore.MainActivity;
import com.S15.MusicStore.R;
import com.S15.MusicStore.Logic.StoreObjects.Artist;
import com.S15.MusicStore.Logic.StoreObjects.Song;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ArtistsAdapter extends ArrayAdapter<Artist> {

	public ArtistsAdapter(Context c, ArrayList<Artist> artists) {
		super(c, R.layout.listview_artist_row, artists);
		listArtists = artists;
		context = c;
		// Toast.makeText(c, String.valueOf(listArtists.size()),
		// Toast.LENGTH_LONG).show();
		// TODO Auto-generated constructor stub
	}

	private Context context;
	private ArrayList<Artist> listArtists;

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflator = LayoutInflater.from(getContext());
		View row = inflator.inflate(R.layout.listview_artist_row, parent, false);

		Artist artist = listArtists.get(position);

		TextView viewartist = (TextView) row.findViewById(R.id.lvartistfullname);
		TextView viewcountry = (TextView) row.findViewById(R.id.lvartistcountry);
		/////////////// the delete icon
		TextView delete = (TextView) row.findViewById(R.id.lvdelartist);
		if (!MainActivity.isAdmin)
			delete.setVisibility(View.GONE);
		else {
			delete.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					AlertDialog.Builder builder = new AlertDialog.Builder(context);
					builder.setMessage("Are you sure to delete?").setNegativeButton("No", null).setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							// Use mListRowPosition for clicked list row...
							Artist item = listArtists.get(position);
							Boolean res = item.Delete(context);
							if (res) {
								listArtists.remove(item);
								notifyDataSetChanged();
							} else {
								Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show();
							}
						}
					});
					builder.show();
				}
			});
		}

		viewartist.setText(artist.FirstName + " " + artist.LastName);
		viewcountry.setText(artist.Country);

		row.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Toast.makeText(context, String.valueOf(position),
				// Toast.LENGTH_LONG).show();
				// TODO Auto-generated method stub
				Activity activity = (Activity) context;
				activity.setContentView(R.layout.artist_detail);
				Artist theArtist = listArtists.get(position);
				TextView fname = (TextView) activity.findViewById(R.id.artistfname);
				TextView lname = (TextView) activity.findViewById(R.id.artistlname);
				TextView gender = (TextView) activity.findViewById(R.id.artistgender);
				TextView country = (TextView) activity.findViewById(R.id.artistcountry);
				fname.setText(theArtist.FirstName);
				lname.setText(theArtist.LastName);
				gender.setText(theArtist.Gender);
				country.setText(theArtist.Country);
				TextView artistid = (TextView)activity.findViewById(R.id.hiddenartistid);
				artistid.setText(String.valueOf(theArtist.Id));
			}
		});
		
		return row;
	}

}
