package com.S15.MusicStore.Logic;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.content.Context;

public class StoreObjects {

	public class Invoice {
		public Integer InvoiceId;
		public Float Total;
		public String Date;
	}

	public Invoice Invoice() {
		return new Invoice();
	}

	public static ArrayList<Invoice> GetInvoices(Integer custid, Context c) {
		ArrayList<Invoice> invoices = new ArrayList<StoreObjects.Invoice>();

		Document xmlInvoices = Support.GetInvoices(String.valueOf(custid), c);
		Element root = xmlInvoices.getDocumentElement();
		NodeList nodes = root.getElementsByTagName("Invoice");
		for (int i = 0; i < nodes.getLength(); i++) {
			StoreObjects.Invoice invoice = new StoreObjects().Invoice();

			for (int n = 0; n < nodes.item(i).getChildNodes().getLength(); n++) {
				Node node = nodes.item(i).getChildNodes().item(n);
				String nodevalue = node.getTextContent();

				if (node.getNodeName().equals("InvoiceId"))
					invoice.InvoiceId = Integer.parseInt(nodevalue);

				else if (node.getNodeName().equals("Total"))
					invoice.Total = Float.parseFloat(nodevalue);

				else if (node.getNodeName().equals("Date"))
					invoice.Date = nodevalue;

			}
			invoices.add(invoice);
		}

		return invoices;
	}

	public class CartItem {
		public Integer OrderId;
		public Integer InvoiceId;
		public String SongTitle;
		public String ArtistFullName;
		public Float Price;

		public Boolean Delete(Context c) {
			// place your deletion process here
			return Support.DeleteCartItem(String.valueOf(this.OrderId), c);
		};
	}

	public CartItem CartItem() {
		return new CartItem();
	}

	public static ArrayList<CartItem> GetCartItems(Integer custid, Context c) {
		ArrayList<CartItem> cartitems = new ArrayList<StoreObjects.CartItem>();

		Document xmlCartItems = Support.GetCartItems(String.valueOf(custid), c);
		Element root = xmlCartItems.getDocumentElement();
		NodeList nodes = root.getElementsByTagName("CartItem");
		for (int i = 0; i < nodes.getLength(); i++) {
			StoreObjects.CartItem cartitem = new StoreObjects().CartItem();

			for (int n = 0; n < nodes.item(i).getChildNodes().getLength(); n++) {
				Node node = nodes.item(i).getChildNodes().item(n);
				String nodevalue = node.getTextContent();
				if (node.getNodeName().equals("OrderId"))
					cartitem.OrderId = Integer.parseInt(nodevalue);

				else if (node.getNodeName().equals("InvoiceId"))
					cartitem.InvoiceId = Integer.parseInt(nodevalue);

				else if (node.getNodeName().equals("SongTitle"))
					cartitem.SongTitle = nodevalue;

				else if (node.getNodeName().equals("ArtistFullName"))
					cartitem.ArtistFullName = nodevalue;

				else if (node.getNodeName().equals("Price"))
					cartitem.Price = Float.parseFloat(nodevalue);

			}
			cartitems.add(cartitem);
		}

		return cartitems;
	}

	public class Artist {
		public Integer Id;
		public String FirstName;
		public String LastName;
		public String Gender;
		public String Country;

		public Boolean Delete(Context c) {
			// place your deletion process here
			return Support.DeleteArtist(String.valueOf(this.Id), c);
		};
	}

	public static Boolean AddArtist(Artist artist, Context c) {
		return Support.AddArtist(artist.FirstName, artist.LastName, artist.Gender, artist.Country, c);

	}

	public static Boolean CartBuy(Integer custid, String creditcard, Context c) {
		return Support.CartBuy(String.valueOf(custid), creditcard, c);

	}

	public Artist Artist() {
		return new Artist();
	}

	public static Boolean AddToCart(Integer custid, Integer songid, Context c) {
		return Support.AddToCart(String.valueOf(custid), String.valueOf(songid), c);
	}

	public static ArrayList<Artist> GetArtists(String search, Context c) {
		ArrayList<Artist> artists = new ArrayList<StoreObjects.Artist>();
		Document xmlArtists = Support.GetArtists(search, c);
		Element root = xmlArtists.getDocumentElement();
		NodeList nodes = root.getElementsByTagName("Artist");
		for (int i = 0; i < nodes.getLength(); i++) {
			StoreObjects.Artist artist = new StoreObjects().Artist();

			for (int n = 0; n < nodes.item(i).getChildNodes().getLength(); n++) {
				Node node = nodes.item(i).getChildNodes().item(n);
				String nodevalue = node.getTextContent();
				if (node.getNodeName().equals("Id"))
					artist.Id = Integer.parseInt(nodevalue);
				else if (node.getNodeName().equals("FirstName"))
					artist.FirstName = nodevalue;
				else if (node.getNodeName().equals("LastName"))
					artist.LastName = nodevalue;
				else if (node.getNodeName().equals("Gender"))
					artist.Gender = nodevalue;
				else if (node.getNodeName().equals("Country"))
					artist.Country = nodevalue;
			}
			artists.add(artist);
		}

		return artists;
	}

	public class Song {
		public Integer Id;
		public String Title;
		public Float Price;
		public String ArtistFullName;
		public Integer ArtistId;
		public String Type;

		public Boolean Delete(Context c) {
			// place your deletion process here
			return Support.DeleteSong(String.valueOf(this.Id), c);
		};
	}

	public Song Song() {
		return new Song();
	}

	public static Boolean AddSong(Song song, Context c) {
		return Support.AddSong(song.Title, song.Type, String.valueOf(song.Price), String.valueOf(song.ArtistId), c);

	}

	public static ArrayList<Song> GetSongs(String search, Context c) {
		ArrayList<Song> songs = new ArrayList<StoreObjects.Song>();
		Document xmlSongs = Support.GetSongs(search, c);
		Element root = xmlSongs.getDocumentElement();
		NodeList nodes = root.getElementsByTagName("Song");
		for (int i = 0; i < nodes.getLength(); i++) {
			StoreObjects.Song song = new StoreObjects().Song();

			for (int n = 0; n < nodes.item(i).getChildNodes().getLength(); n++) {
				Node node = nodes.item(i).getChildNodes().item(n);
				String nodevalue = node.getTextContent();
				if (node.getNodeName().equals("Id"))
					song.Id = Integer.parseInt(nodevalue);

				else if (node.getNodeName().equals("Title"))
					song.Title = nodevalue;

				else if (node.getNodeName().equals("Price"))
					song.Price = Float.parseFloat(nodevalue);

				else if (node.getNodeName().equals("ArtistFullName"))
					song.ArtistFullName = nodevalue;

				else if (node.getNodeName().equals("ArtistId"))
					song.ArtistId = Integer.parseInt(nodevalue);

				else if (node.getNodeName().equals("Type"))
					song.Type = nodevalue;
			}
			songs.add(song);
		}

		return songs;
	}

	public static ArrayList<Song> GetInvoiceSongs(Integer invoiceid, Context c) {
		ArrayList<Song> songs = new ArrayList<StoreObjects.Song>();
		Document xmlSongs = Support.GetInvoiceSongs(String.valueOf(invoiceid), c);
		Element root = xmlSongs.getDocumentElement();
		NodeList nodes = root.getElementsByTagName("Song");
		for (int i = 0; i < nodes.getLength(); i++) {
			StoreObjects.Song song = new StoreObjects().Song();

			for (int n = 0; n < nodes.item(i).getChildNodes().getLength(); n++) {
				Node node = nodes.item(i).getChildNodes().item(n);
				String nodevalue = node.getTextContent();

				if (node.getNodeName().equals("Title"))
					song.Title = nodevalue;

				else if (node.getNodeName().equals("Price"))
					song.Price = Float.parseFloat(nodevalue);

				else if (node.getNodeName().equals("ArtistFullName"))
					song.ArtistFullName = nodevalue;

			}
			songs.add(song);
		}

		return songs;
	}

}