package com.S15.MusicStore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MenuActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_menu);
		if (MainActivity.isAdmin) {
			findViewById(R.id.mul).setVisibility(View.GONE);
		}
		Toast.makeText(this, "Welcome to our MusicStore! :)", Toast.LENGTH_LONG).show();
	}

	public void ViewClick(View view) {
		int id = view.getId();
		Intent intent = null;
		switch (id) {
		case R.id.btnMenuArtists:
			intent = new Intent(this, ArtistsActivity.class);
			break;

		case R.id.btnMenuSongs:
			intent = new Intent(this, SongsActivity.class);
			break;

		case R.id.btnMenuSearchArtists:
			intent = new Intent(this, SearchArtistActivity.class);
			break;
		case R.id.btnMenuSearchSongs:
			intent = new Intent(this, SearchSongActivity.class);
			break;
		case R.id.btnMenuMyCart:
			intent = new Intent(this, CartActivity.class);
			break;
		case R.id.btnMenuPurchases:
			intent = new Intent(this, InvoicesActivity.class);
			break;
		}
		startActivity(intent);
	}

}
