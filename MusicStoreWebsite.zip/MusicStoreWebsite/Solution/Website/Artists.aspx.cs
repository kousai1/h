using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Artists : System.Web.UI.MobileControls.MobilePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["admin"] == null) Server.Transfer("~/default.aspx");
            if ((bool)Session["admin"] == false)
            {
                olArtists.Commands.Remove("delete");
                lnkAddArtist.Visible = false;
            }
            olArtists.DataSource = DAL.Artists();
            Page.DataBind();
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            DAL.AddArtist(txtfname.Text, txtlname.Text, selgender.Items[selgender.SelectedIndex].Text, selcountry.Items[selcountry.SelectedIndex].Text);
            Server.Transfer("~/Artists.aspx");
        }
    }
    protected void olArtists_ItemCommand(object sender, ObjectListCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string id = e.ListItem["id"];
            DAL.DeleteArtist(int.Parse(id));
            Server.Transfer("~/Artists.aspx");
        }
    }
}
