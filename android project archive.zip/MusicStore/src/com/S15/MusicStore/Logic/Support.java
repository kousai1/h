package com.S15.MusicStore.Logic;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import android.util.Log;
import android.widget.Toast;

/*
NodeList tagsList = root.getElementsByTagName("Tag");
for (int i = 0; i < tagsList.getLength(); i++) {
    Node tagNode = tagsList.item(i);
    Tag tag = new Tag(tagNode.getTextContent());
    tags.TagsList.add(tag);
}
*/
public class Support {

	public static void SaveURL(String url, Context c) {
		SharedPreferences preferences = c.getSharedPreferences("prefName", c.MODE_PRIVATE);
		SharedPreferences.Editor edit = preferences.edit();

		edit.putString("URL", url);
		edit.commit();
	}

	public static String GetURL(Context c) {
		SharedPreferences preferences = c.getSharedPreferences("prefName", c.MODE_PRIVATE);
		return preferences.getString("URL", "");
	}

	public static Boolean ValidateAdmin(String pw, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "CorrectAdmin";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("pw", pw));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Boolean DeleteSong(String id, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "DeleteSong";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("id", id));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Boolean DeleteArtist(String id, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "DeleteArtist";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("id", id));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Boolean CartBuy(String custid, String creditcard, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "CartBuy";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("custid", custid));
			nameValuePairs.add(new BasicNameValuePair("cc", creditcard));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Boolean AddArtist(String fname, String lname, String gender, String country, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "AddArtist";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("fname", fname));
			nameValuePairs.add(new BasicNameValuePair("lname", lname));
			nameValuePairs.add(new BasicNameValuePair("gender", gender));
			nameValuePairs.add(new BasicNameValuePair("country", country));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Boolean AddSong(String title, String type, String price, String artistid, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "AddSong";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("title", title));
			nameValuePairs.add(new BasicNameValuePair("type", type));
			nameValuePairs.add(new BasicNameValuePair("price", price));
			nameValuePairs.add(new BasicNameValuePair("artistid", artistid));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Integer Login(String un, String pw, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "Login";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("un", un));
			nameValuePairs.add(new BasicNameValuePair("pw", pw));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return 0;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Integer.parseInt(root.getTextContent());
			}
		} catch (Exception e) {
			return 0;
		}
	}

	public static Boolean Register(String un, String pw, String fn, String ln, String addr, String mail, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "Register";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("un", un));
			nameValuePairs.add(new BasicNameValuePair("pw", pw));
			nameValuePairs.add(new BasicNameValuePair("fn", fn));
			nameValuePairs.add(new BasicNameValuePair("ln", ln));
			nameValuePairs.add(new BasicNameValuePair("addr", addr));
			nameValuePairs.add(new BasicNameValuePair("email", mail));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();
				// root.getTextContent();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {

			return false;
		}
	}

	public static Document GetCartItems(String custid, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "GetCartItems";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("custid", custid));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return null;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));

				return xmlDoc;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static Document GetInvoices(String custid, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "GetInvoices";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("custid", custid));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return null;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));

				return xmlDoc;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static Document GetArtists(String search, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "GetArtists";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("search", search));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return null;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));

				return xmlDoc;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static Document GetInvoiceSongs(String invoiceid, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "GetInvoiceSongs";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("invoiceid", invoiceid));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return null;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));

				return xmlDoc;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static Document GetSongs(String search, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "GetSongs";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("search", search));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return null;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));

				return xmlDoc;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static Boolean DeleteCartItem(String orderid, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "DeleteCartItem";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("orderid", orderid));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	public static Boolean AddToCart(String custid, String songid, Context c) {
		try {
			String URL = "http://" + GetURL(c) + "AddToCart";
			Log.d("URL", URL);
			HttpPost httppost = new HttpPost(URL);
			httppost.setHeader("Content-type", "application/x-www-form-urlencoded");
			httppost.setHeader("Accept", "*/*");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("songid", songid));
			nameValuePairs.add(new BasicNameValuePair("custid", custid));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			Sender sender = new Sender();
			String XMLresult = sender.execute(httppost).get();
			if (XMLresult.equals("error")) {
				Toast.makeText(c, "Connection Error", Toast.LENGTH_SHORT).show();
				return false;
			} else {
				DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document xmlDoc = docBuilder.parse(new InputSource(new StringReader(XMLresult)));
				Element root = xmlDoc.getDocumentElement();

				return Boolean.parseBoolean(root.getTextContent());
			}
		} catch (Exception e) {
			return false;
		}
	}

	private static class Sender extends AsyncTask<HttpPost, String, String> {

		@Override
		protected String doInBackground(HttpPost... param) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = param[0];
			try {
				HttpResponse httpresponse = httpclient.execute(httppost);
				HttpEntity entity = httpresponse.getEntity();
				String xmlResutl = EntityUtils.toString(entity);
				Log.d("result", xmlResutl.toString());
				return xmlResutl;
			} catch (Exception e) {
				return "error";
			}
		}

	}
}
