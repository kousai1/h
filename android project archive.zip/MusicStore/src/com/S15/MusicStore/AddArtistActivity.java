package com.S15.MusicStore;

import com.S15.MusicStore.Logic.StoreObjects;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class AddArtistActivity extends Activity {

	EditText fname;
	EditText lname;
	RadioGroup gender;
	Spinner country;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_artist);

		fname = (EditText) findViewById(R.id.txtartistfname);
		lname = (EditText) findViewById(R.id.txtartistlname);
		gender = (RadioGroup) findViewById(R.id.radioartistgender);
		country = (Spinner) findViewById(R.id.spinnerartistcountry);
	}

	public void ViewClick(View v) {
		switch (v.getId()) {
		case R.id.btnaddartist:
			if (fname.getText().toString().matches("")) {
				Toast.makeText(this, "First Name is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (lname.getText().toString().matches("")) {
				Toast.makeText(this, "Last Name is required", Toast.LENGTH_SHORT).show();
				return;
			}
			if (gender.getCheckedRadioButtonId() == -1) {
				Toast.makeText(this, "Gender is required", Toast.LENGTH_SHORT).show();
				return;
			}
			StoreObjects.Artist artist = new StoreObjects().Artist();
			artist.FirstName = fname.getText().toString();
			artist.LastName = lname.getText().toString();
			artist.Gender = ((RadioButton) findViewById(gender.getCheckedRadioButtonId())).getText().toString();
			artist.Country = country.getItemAtPosition(country.getSelectedItemPosition()).toString();
			Boolean result = StoreObjects.AddArtist(artist, this);
			if (result) {
				Toast.makeText(this, "New Artist added!", Toast.LENGTH_SHORT).show();
				fname.setText("");
				lname.setText("");
			} else {
				Toast.makeText(this, "failed! try later", Toast.LENGTH_SHORT).show();
			}

			break;
		case R.id.btncanceladdartist:
			this.finish();
			break;
		}
	}

}
