package com.S15.MusicStore;

import java.util.ArrayList;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.StoreObjects.Artist;
import com.S15.MusicStore.Logic.StoreObjects.Song;
import com.S15.MusicStore.Logic.Support;

import CustomListAdapters.ArtistsAdapter;
import CustomListAdapters.SongsAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class SongsActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		artistid = getIntent().getIntExtra("artistid", 0);
		songsearch = getIntent().getStringExtra("songsearch");

		PrepareList();
	}

	String songsearch;
	Integer artistid;
	private int updated;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.songs_menu, menu);
		if (!MainActivity.isAdmin)
			return false;
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if (item.getItemId() == R.id.songaddnew) {
			Intent intent = new Intent(this, AddSongActivity.class);
			startActivityForResult(intent, updated);
		}
		return true;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		PrepareList();
	}

	public void ViewClick(View v) {
		switch (v.getId()) {
		case R.id.btnbuysong:
			TextView songidview = (TextView) findViewById(R.id.songdetailid);
			Integer songid = Integer.parseInt(songidview.getText().toString());
			Boolean result = StoreObjects.AddToCart(MainActivity.uid, songid, this);
			if (result) {
				Toast.makeText(this, "Song added to cart!", Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.btncancelsongdetail:
			break;
		}
		PrepareList();
	}

	private void PrepareList() {
		setContentView(R.layout.activity_songs);
		ArrayList<Song> songs = StoreObjects.GetSongs(songsearch, this);
		if (artistid != 0) {
			for (int i = 0; i < songs.size(); i++) {
				if (songs.get(i).ArtistId != artistid) {
					songs.remove(i);
					i--;
				}
			}
		}
		ListView lv = (ListView) findViewById(R.id.lvsongs);
		SongsAdapter adp = new SongsAdapter(this, songs);
		lv.setAdapter(adp);
	}

}
