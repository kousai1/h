package com.S15.MusicStore;

import java.util.ArrayList;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.StoreObjects.CartItem;

import CustomListAdapters.CartItemsAdapter;
import CustomListAdapters.InvoiceSongsAdapter;
import CustomListAdapters.InvoicesAdapter;
import android.app.Activity;
import android.content.Intent;
import android.database.CursorJoiner.Result;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

public class InvoiceSongsActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_invoice_songs);
		
		Integer invoiceid = Integer.parseInt(getIntent().getStringExtra("invoiceid"));		
		
		ListView lv = (ListView) findViewById(R.id.lvinvoicesongs);
		InvoiceSongsAdapter adp = new InvoiceSongsAdapter(this, StoreObjects.GetInvoiceSongs(invoiceid, this));
		lv.setAdapter(adp);
	}

}
