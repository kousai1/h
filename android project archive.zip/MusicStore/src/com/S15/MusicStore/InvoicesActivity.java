package com.S15.MusicStore;

import java.util.ArrayList;

import com.S15.MusicStore.Logic.StoreObjects;
import com.S15.MusicStore.Logic.StoreObjects.CartItem;

import CustomListAdapters.CartItemsAdapter;
import CustomListAdapters.InvoicesAdapter;
import android.app.Activity;
import android.content.Intent;
import android.database.CursorJoiner.Result;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

public class InvoicesActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_invoices);
		
		ListView lv = (ListView) findViewById(R.id.lvinvoices);
		InvoicesAdapter adp = new InvoicesAdapter(this, StoreObjects.GetInvoices(MainActivity.uid, this));
		lv.setAdapter(adp);
	}

}
